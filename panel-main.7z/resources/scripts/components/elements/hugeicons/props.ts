export interface HugeIconProps {
    fill: string;
    className?: string;
}
