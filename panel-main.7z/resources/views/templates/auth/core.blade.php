@extends('templates/wrapper', [
    'css' => ['body' => 'bg-zinc-900']
])

@section('container')
    <div id="app"></div>
@endsection
